namespace CentroEventos.Aplicacion.Excepciones;

public class EntidadNotFoundException:Exception {
    public EntidadNotFoundException(string m):base(m){}
}
